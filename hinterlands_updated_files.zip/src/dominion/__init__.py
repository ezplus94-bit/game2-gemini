"""Modinion: a modular, testable deck-building game engine (the Python package keeps the name `dominion`)."""

from .cards.base import CardDef, CardType, action, action_victory, duration, treasure, treasure_victory, victory
from .cards.registry import (
    UnknownCardError, expansions, get_card, kingdom_cards, register, unregister,
)
from .cards import basic, kingdom, prosperity, alchemy, seaside, Cornucopia  # noqa: F401  (importing these registers the cards)

__version__ = "0.12.0"

__all__ = [
    "CardDef", "CardType", "action", "action_victory", "duration", "treasure", "treasure_victory", "victory",
    "UnknownCardError", "expansions", "get_card", "kingdom_cards", "register", "unregister",
]

# --- Hinterlands (2011 / 2nd Edition 2022) Registration ---
from .cards.hinterlands import (
    EXPANSION_ID as HINTERLANDS_ID,
    EXPANSION_NAME as HINTERLANDS_NAME,
    HINTERLANDS_CARDS,
    HINTERLANDS_2E_CARDS,
    HINTERLANDS_1E_CARDS,
)

if "EXPANSIONS" in globals() and isinstance(globals()["EXPANSIONS"], dict):
    globals()["EXPANSIONS"]["hinterlands"] = HINTERLANDS_CARDS
elif "EXPANSIONS" in globals() and isinstance(globals()["EXPANSIONS"], list):
    if "hinterlands" not in globals()["EXPANSIONS"]:
        globals()["EXPANSIONS"].append("hinterlands")

# --- Dark Ages (2012) Registration ---
DARK_AGES_EXPANSION = {
    "id": "dark_ages",
    "name": "Dark Ages",
    "year": 2012,
    "kingdom_count": 35,
    "has_shelters": True,
    "has_ruins": True,
}
try:
    if "EXPANSIONS" in globals():
        if isinstance(EXPANSIONS, dict):
            EXPANSIONS["dark_ages"] = DARK_AGES_EXPANSION
        elif isinstance(EXPANSIONS, list) and "dark_ages" not in EXPANSIONS and "Dark Ages" not in EXPANSIONS:
            EXPANSIONS.append("dark_ages")
    else:
        EXPANSIONS = {"dark_ages": DARK_AGES_EXPANSION}
except Exception:
    pass

# --- Guilds (2013 / 2024 2E) Registration ---
from dominion.cards.guilds import (
    GUILDS_EXPANSION_NAME,
    GUILDS_ALL_KINGDOM_CARDS,
    REWARDS as GUILDS_REWARDS,
)
