# --- Hinterlands Game Loop Integration ---
from .cards.hinterlands import (
    HINTERLANDS_CARDS,
    _gain_card as hinterlands_gain_card,
    _discard_card as hinterlands_discard_card,
    _trash_card as hinterlands_trash_card,
    _card_cost as hinterlands_card_cost,
)

# --- dark_ages_gain_card ---
from .cards.dark_ages import _gain_card as dark_ages_gain_card

# --- guilds_gain_card ---
from dominion.cards.guilds import (
    guilds_on_gain_card as guilds_gain_card,
    add_coffers,
    spend_coffers,
)
